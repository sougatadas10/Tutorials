
module com.packtpub.mmj.lib {

    exports com.packtpub.mmj.lib.model to com.packtpub.mmj.rest;

    opens com.packtpub.mmj.lib.model;
}
