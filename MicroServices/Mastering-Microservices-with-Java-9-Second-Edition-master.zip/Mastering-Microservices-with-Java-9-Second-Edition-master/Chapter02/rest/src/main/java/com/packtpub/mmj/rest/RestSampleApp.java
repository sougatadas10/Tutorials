package com.packtpub.mmj.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @author sousharm
 */
@SpringBootApplication
public class RestSampleApp {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(RestSampleApp.class, args);
    }
}
